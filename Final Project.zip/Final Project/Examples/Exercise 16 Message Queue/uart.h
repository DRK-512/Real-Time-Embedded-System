extern void USART1_Init (void);
extern void USART2_Init (void);
extern void USART3_Init (void);

extern int SendChar (uint8_t ch, uint8_t UartNum); 

/*
extern uint8_t GetKey (void);
volatile extern uint8_t inKey;
*/
