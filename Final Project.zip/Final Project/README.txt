The project file can be found in 
Examples->Exercise 16 Message Queue->CMSISrtxMessageQueue.uvprojx